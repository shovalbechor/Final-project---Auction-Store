import React from "react";
import LoadingButton from "@mui/lab/LoadingButton";
import GetProducts from "../Components/Inputs/GetProducts";
import SellingInfo from "../Components/Inputs/SellingInfo";
import ProductModifying from "../Components/Inputs/ProductModifying";
import ChangeRoles from "../Components/Inputs/ChangeRoles";
import SellInput from "../Components/Inputs/SellInput";
import {messagesInterface, Product, selection} from "../Components/mainScreens/Screen";
import "../styles/screenFunctions.css";
import {gql, GraphQLClient} from "graphql-request";
import CheckRoundedIcon from "@mui/icons-material/CheckRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";


const query = gql`
	mutation addBid($productName:String!,$userId:String!){
		addBid(productName: $productName, userId: $userId){
			id, price, lastBidName
		}
	}
`;
export function GetTiles(props: { role: string, handler: (e: React.MouseEvent<HTMLButtonElement>) => void }) {
	const {handler, role} = props;
	const options = [
		<LoadingButton
			key={"0 - Worker Manger"}
			size="large"
			onClick={handler}
			value="0"
			variant="contained"
		>Get Items
		</LoadingButton>,
		<LoadingButton
			key={"2 - Manger"}
			size="large"
			onClick={handler}
			variant="contained"
			value="2"
		>add/adjust Item</LoadingButton>,
		<LoadingButton
			key={"3 - Manger"}
			size="large"
			onClick={handler}
			value="3"
			variant="contained">
			change roles
		</LoadingButton>];
	return <div className="OptionsContainer">
		{options.filter((item) => {
			return ((item.key as string).includes(role));
		})
		}
	</div>;
}

export function ShowError(props: { messages: messagesInterface }) {
	(document.querySelector(".data-container") as HTMLDivElement)!.style.display = "flex";
	const {message, error} = props.messages;
	if (error)
		return <p className="message error">{error}</p>;
	else
		return <p className="message">{message}</p>;
}

function GetClientMassage(props: { quantity: number }) {
	const quantity = props.quantity;
	const isAvailable = quantity > 0;
	if (isAvailable) {
		return <div className={"clientMassage"}>
			<h1 className={"availableMassage"}>Available</h1>
			<CheckRoundedIcon sx={{color: "#18900a"}}/>
		</div>;
	} else {
		return <div className={"clientMassage"}>
			<h1 className={"soldOutMassage"}>Sold Out</h1>
			<CloseRoundedIcon sx={{color: "#900a0a"}}/>
		</div>;
	}
}
function zeroPad(num: number, numZeros: number) {
	const n = Math.abs(num);
	const zeros = Math.max(0, numZeros - Math.floor(n).toString().length );
	let zeroString = Math.pow(10,zeros).toString().substr(1);
	if( num < 0 ) {
		zeroString = "-" + zeroString;
	}

	return zeroString+n;
}
export function ShowData(props: { data: Array<Product>, role: string , graphqlClient: GraphQLClient, userId:string, userName:string}) {
	const {data, role, graphqlClient, userId, userName} = props;
	const isClient = role === "Client";
	const isManger = role === "Manger";
	return <>
		{data.map((item: Product, key: number ) => {
			const {name, imgSrc, lastBidName, price, expiredAt} = item;
			const expiredDate  = (new Date(parseInt(expiredAt)+ 1000*3*60*60).getTime())- Date.now();
			const hours = zeroPad(Math.floor(expiredDate / (1000 * 60 * 60)),2);
			const minutes = zeroPad(Math.floor(expiredDate / (1000 * 60)) % 60,2);
			const available = (parseInt(hours) > 0 || parseInt(minutes) > 0);
			const className = (expiredDate > 0) ? "inner-data-container" +
				" inner-data-container-green" : "inner-data-container inner-data-container-red";
			let bidderName = (lastBidName !== null)? lastBidName : "no one";
			return <div  key={key} className={className} onClick={
				() => {
					if (isClient && expiredDate > 0 && bidderName !== userName) {
						alert(`You have just bid on item: ${name}`);
						graphqlClient.request(query, {
							productName: name,
							userId
						}).catch((e) => {
							console.log(e);
							alert("An error occurred, please try again later");
						}).then(() => {
							bidderName = userName;
						});
					}
				}
			}>
				<img src={imgSrc} alt="product image"/>
				<h1 style={{textAlign: "center"}}>{name}</h1>
				{available ? <h1 className={"itemPrice"}>price: {price}$</h1> : <h1 className={"itemPrice"}>Sold for: {price}$</h1>}
				{isManger && (available ? <h1 className={"bidderNames"}>{bidderName} is currently in the lead</h1> : <h1 className={"bidderNames"}>Sold to: {bidderName}</h1>)}
				{!isManger && available && (bidderName !== userName ? <h1 className={"bidderNames"}>Bid now!</h1> : <h1 className={"bidderNames"}>You are currently in the lead</h1>)}
				{available ? <h1 style={{textAlign: "center"}}>Expired in: {hours}:{minutes}</h1> :  <h1 style={{textAlign: "center",textDecoration: "underline"}}>Expired</h1> }
			</div>;
		})}
	</>;
}

export function GetContent(props: { role: string, timeOutExecutor: () => void, select: selection, clear: () => void, graphqlClient: GraphQLClient, showMessages: (messages: messagesInterface) => void, changeFunction: (data: Array<Product>) => void }) {
	const {
		select,
		changeFunction,
		showMessages,
		clear,
		graphqlClient,
		timeOutExecutor,
		role
	} = props;
	switch (select) {
	case selection.search:
		return <GetProducts
			role={role}
			timeOutExecutor={timeOutExecutor}
			graphqlClient={graphqlClient}
			changeFunction={changeFunction}
			showMessages={showMessages}
			clearData={clear}/>;
	case selection.getList:
		return <SellingInfo
			timeOutExecutor={timeOutExecutor}
			graphqlClient={graphqlClient}
			changeFunction={changeFunction}
			showMessages={showMessages}
			clearData={clear}/>;
	case selection.addAdjDelProduct:
		return <ProductModifying
			timeOutExecutor={timeOutExecutor}
			graphqlClient={graphqlClient}
			changeFunction={changeFunction}
			showMessages={showMessages}
			clearData={clear}/>;
	case selection.roles:
		return <ChangeRoles
			timeOutExecutor={timeOutExecutor}
			graphqlClient={graphqlClient}
			showMessages={showMessages} clearData={clear}/>;
	case selection.insertASell:
		return <SellInput
			timeOutExecutor={timeOutExecutor}
			graphqlClient={graphqlClient}
			changeFunction={changeFunction}
			showMessages={showMessages}
			clearData={clear}/>;
	}
}

export function TimeOutMassage(props: { logout: () => void }) {
	const logout = props.logout;
	return <div className={"TimeOutMassage"}>
		<div className="TimeOutMassage-inner">
			<h2>The session is over.</h2>
			<h2>Please login again.</h2>
			<LoadingButton
				onClick={logout}
				sx={{
					backgroundColor: "#ff9e37",
					fontWeight: "bold",
					color: "#000000",
					"&:hover": {backgroundColor: "#f8ac5b"}
				}}
				variant="contained">
				Reconnect
			</LoadingButton>
		</div>
	</div>;
}
