import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    PrimaryColumn,
    Unique
} from "typeorm"

@Entity("Product-sh")
 export class Product {

    @PrimaryGeneratedColumn()
    id: number;

    @Column({ unique: true })
    name: string;

    @Column()
    price: number;

    @Column()
    imgSrc: string;

    @Column({nullable: true})
    lastBidName: string;

    @Column({nullable: true})
    lastBidId: string;

    @Column({type:"timestamp"})
    expiredAt: Date;

    @Column({default:false})
    informed: boolean;
}
