"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
if (process.env.NODE_ENV !== 'production') {
    dotenv_1.default.config();
}
const express_1 = __importDefault(require("express"));
require("reflect-metadata");
const express_graphql_1 = require("express-graphql");
const data_source_1 = require("./data-source");
const checkPermission_1 = require("./utils/checkPermission");
const schema_1 = require("./GraphQl/schema");
const confirmUser_1 = require("./utils/confirmUser");
const PORT = process.env.PORT || 3001;
const app = (0, express_1.default)();
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', process.env.FRONTEND_URL);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,Authorization');
    if ('OPTIONS' == req.method)
        return res.sendStatus(204);
    next();
});
app.use(express_1.default.json());
app.get("/user/confirm/:pram", async (req, res) => {
    await (0, confirmUser_1.confirmUser)(req.params.pram, res);
});
app.use('/server', checkPermission_1.checkPermission, (0, express_graphql_1.graphqlHTTP)({
    schema: schema_1.schema,
    rootValue: schema_1.root
}));
app.use('', (req, res) => {
    res.status(404).send("page not found");
});
app.listen(PORT, async () => {
    await data_source_1.AppDataSource.initialize();
    console.log(`listening on port ${PORT}`);
});
