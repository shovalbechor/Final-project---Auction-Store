"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.usersRepository = exports.productRepository = exports.AppDataSource = void 0;
require("reflect-metadata");
const typeorm_1 = require("typeorm");
const product_1 = require("./entity/product");
const User_1 = require("./entity/User");
exports.AppDataSource = new typeorm_1.DataSource({
    type: "postgres",
    host: process.env.DB_HOST,
    port: 5432,
    username: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    synchronize: false,
    logging: false,
    extra: {
        ssl: {
            rejectUnauthorized: false
        }
    },
    entities: [product_1.Product, User_1.User],
    migrations: [],
    subscribers: [],
});
exports.productRepository = exports.AppDataSource.getRepository(product_1.Product);
exports.usersRepository = exports.AppDataSource.getRepository(User_1.User);
