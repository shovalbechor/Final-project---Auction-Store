"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resetUserPassword = exports.requestPasswordLink = exports.changeRole = exports.login = exports.register = void 0;
const data_source_1 = require("../data-source");
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const typeorm_1 = require("typeorm");
const linksGenerator_1 = require("../utils/linksGenerator");
const emailClient_1 = require("../utils/emailClient");
const DUPLICATE_KEY_ERROR_CODE = "23505";
const register = async ({ username, email, password }) => {
    username = username.toLowerCase();
    const hashPassword = await bcrypt_1.default.hash(password, 10);
    try {
        const user = await data_source_1.usersRepository.save({
            username,
            email,
            password: hashPassword
        });
        const link = (0, linksGenerator_1.generateConfirmationLink)(process.env.BACKEND_URL, user.id);
        const mailOptions = (0, emailClient_1.generateConfirmationBodyMail)(email, username, link);
        const status = await (0, emailClient_1.sendEmail)(email, username, mailOptions, link);
        if (!status)
            throw new Error("Email not sent");
        return "Enter your email to confirm your account";
    }
    catch (e) {
        if (e instanceof typeorm_1.QueryFailedError) {
            if (e.driverError.code === DUPLICATE_KEY_ERROR_CODE && e.driverError.constraint === 'UQ_user_email')
                throw new Error(`This email is taken`);
        }
        throw new Error("User failed to be created...");
    }
};
exports.register = register;
const login = async ({ email, password }) => {
    const TTL = parseInt(process.env.TTL);
    email = email.toLowerCase();
    const user = await data_source_1.usersRepository.findOneBy({ email });
    if (!user) {
        throw new Error("Email / password is incorrect!");
    }
    if (!user.confirmed) {
        throw new Error("Please confirm your email address");
    }
    const isAuthorities = await bcrypt_1.default.compare(password, user.password);
    if (isAuthorities) {
        const token = jsonwebtoken_1.default.sign({ user }, process.env.JWT_SECRET, {
            expiresIn: TTL
        });
        return (token);
    }
    throw new Error("Email / password is incorrect!");
};
exports.login = login;
const changeRole = async ({ email, reqRole }) => {
    email = email.toLowerCase();
    const user = await data_source_1.usersRepository.findOneBy({ email });
    if (!user) {
        throw new Error(`There is no user with email: ${email}`);
    }
    user.role = reqRole;
    await data_source_1.usersRepository.update({ username: user.username }, user);
    return user;
};
exports.changeRole = changeRole;
const requestPasswordLink = async ({ email }) => {
    let user;
    try {
        user = await data_source_1.usersRepository.findOneBy({ email });
    }
    catch (e) {
        throw new Error("Password reset link not sent");
    }
    if (!user) {
        throw new Error(`There is no user with email: ${email}`);
    }
    const link = (0, linksGenerator_1.generateRequestPasswordLink)(process.env.FRONTEND_URL, user.id);
    const mailOptions = (0, emailClient_1.generateRequestPasswordBodyMail)(email, user.username, link);
    const status = await (0, emailClient_1.sendEmail)(email, user.username, mailOptions, link);
    if (!status)
        throw new Error("Email not sent");
    return "Enter the link in your email to reset your password";
};
exports.requestPasswordLink = requestPasswordLink;
const resetUserPassword = async ({ userId, password }) => {
    const user = await data_source_1.usersRepository.findOne({ where: { id: userId } });
    if (!user) {
        throw new Error("Page not found");
    }
    user.password = await bcrypt_1.default.hash(password, 10);
    await data_source_1.usersRepository.update({ id: userId }, user);
    return `Password changed successfully`;
};
exports.resetUserPassword = resetUserPassword;
