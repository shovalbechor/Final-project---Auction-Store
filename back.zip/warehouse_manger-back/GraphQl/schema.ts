import {
    buildSchema,
    GraphQLSchema
} from "graphql";
import {
    // bestSellingProducts,
    getAllProducts, searchForProducts,
    // worstSellingProducts,
    // productStatus
} from "./productsQuery";
import {
    deleteAnProduct,
    changePropertiesOfProduct, addAnProduct, addBid
} from "./productsMutation";
import {changeRole, login, register, requestPasswordLink, resetUserPassword} from "./usersMutation";


export const schema: GraphQLSchema = buildSchema(`
    type Product{
        id: Int
        name: String
        price: Int
        imgSrc: String
        lastBidName: String
        expiredAt: String
    }type User{
        id: Int
        username: String
        password: String
        role: String
    }
    type Availability{
        name:String
        status: String
        message:String
    }
    type Query {
        searchForProducts(name: String!):[Product]
        getAllProducts: [Product]
    }
    type Mutation {
        addAnProduct(name: String!,imgSrc: String!,price: Float): Product
        deleteAnProduct(name: String!): Product
        changePropertiesOfProduct(previousName: String!,name: String,imgSrc: String):Product
        login(email: String!,password:String!):String
        register(username: String!,email:String!,password:String!):String
        changeRole(email: String!,reqRole:String!):User
        requestPasswordLink(email:String!):String
        addBid(productName:String!,userId:String!):Product
        resetUserPassword(userId:String!, password:String!):String
    }
`);

export const root = {
    searchForProducts,
    // productStatus,
    getAllProducts,
    // bestSellingProducts,
    // worstSellingProducts,
    addAnProduct,
    // makeASell,
    deleteAnProduct,
    addBid,
    changePropertiesOfProduct,
    login,
    register,
    changeRole,
    requestPasswordLink,
    resetUserPassword
}
