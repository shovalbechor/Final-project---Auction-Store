"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.changePropertiesOfProduct = exports.deleteAnProduct = exports.makeASell = exports.addAnProduct = void 0;
const data_source_1 = require("../data-source");
const inputHandler_1 = require("../utils/inputHandler");
const typeorm_1 = require("typeorm");
const getFormattedName_1 = require("../utils/getFormattedName");
const addAnProduct = async ({ name, quantity, imgSrc }) => {
    try {
        const nameFormatted = (0, getFormattedName_1.getFormattedName)(name);
        return await data_source_1.productRepository.save({
            name: nameFormatted,
            quantity,
            imgSrc
        });
    }
    catch (err) {
        if (err instanceof typeorm_1.QueryFailedError && err.driverError.code === "23505") {
            throw new Error(`Name is already taken: '${name}'`);
        }
    }
};
exports.addAnProduct = addAnProduct;
const makeASell = async ({ nameOfProduct, numberOfItemsSold }) => {
    nameOfProduct = (0, getFormattedName_1.getFormattedName)(nameOfProduct);
    const nameLower = nameOfProduct.toLowerCase();
    const item = await data_source_1.productRepository.createQueryBuilder("product").where("LOWER(product.name)" +
        " = :name", { name: nameLower }).getOne();
    if (!item)
        throw new Error(`'${nameOfProduct}' doesn't exist!`);
    (0, inputHandler_1.checkIfQuantityIsValid)(item.quantity, numberOfItemsSold);
    item.quantity -= numberOfItemsSold;
    item.numberOfSales++;
    await data_source_1.productRepository.update({ name: item.name }, item);
    return item;
};
exports.makeASell = makeASell;
const deleteAnProduct = async ({ name }) => {
    const nameLower = name.toLowerCase();
    const item = await data_source_1.productRepository.createQueryBuilder("product").where("LOWER(product.name)" +
        " = :name", { name: nameLower }).getOne();
    if (!item)
        throw new Error(`'${name}' doesn't exist!`);
    await data_source_1.productRepository.delete({ name: item.name });
    return item;
};
exports.deleteAnProduct = deleteAnProduct;
const changePropertiesOfProduct = async (args) => {
    const { previousName, ...newProperties } = args;
    const previousNameLower = previousName.toLowerCase();
    newProperties.name = (0, getFormattedName_1.getFormattedName)(args.name);
    const item = await data_source_1.productRepository.createQueryBuilder("product").where("LOWER(product.name)" +
        " = :name", { name: previousNameLower }).getOne();
    if (!item)
        throw new Error(`Product doesn't exist: '${previousName}'`);
    for (const property in newProperties) {
        const requestedValue = newProperties[property];
        if (requestedValue !== "" && requestedValue != null) {
            item[property] = requestedValue;
        }
    }
    try {
        await data_source_1.productRepository.update({ id: item.id }, item);
        return item;
    }
    catch (err) {
        if (err instanceof typeorm_1.QueryFailedError && err.driverError.code === "23505")
            throw new Error(`Name is already taken: '${args.name}'`);
    }
};
exports.changePropertiesOfProduct = changePropertiesOfProduct;
