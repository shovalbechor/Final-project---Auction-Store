"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.root = exports.schema = void 0;
const graphql_1 = require("graphql");
const productsQuery_1 = require("./productsQuery");
const productsMutation_1 = require("./productsMutation");
const usersMutation_1 = require("./usersMutation");
exports.schema = (0, graphql_1.buildSchema)(`
    type Product{
        id: Int
        name: String
        quantity: Int
        imgSrc: String
        numberOfSales: Int
    }type User{
        id: Int
        username: String
        password: String
        role: String
    }
    type Availability{
        name:String
        status: String
        message:String
    }
    type Query {
        searchForProducts(name: String!):[Product]
        productStatus(name: String):Availability
        getAllProducts: [Product]
        worstSellingProducts(limit: Int): [Product]
        bestSellingProducts(limit: Int): [Product]
    }
    type Mutation {
        makeASell(nameOfProduct: String!, numberOfItemsSold: Int!): Product
        addAnProduct(name: String!,quantity: Int!,imgSrc:String!): Product
        deleteAnProduct(name: String!): Product
        changePropertiesOfProduct(previousName: String!,name: String,imgSrc: String,quantity: Int,numberOfSales:Int):Product
        login(email: String!,password:String!):String
        register(username: String!,email:String!,password:String!):String
        changeRole(email: String!,reqRole:String!):User
        requestPasswordLink(email:String!):String
        resetUserPassword(userId:String!, password:String!):String
    }
`);
exports.root = {
    searchForProducts: productsQuery_1.searchForProducts,
    productStatus: productsQuery_1.productStatus,
    getAllProducts: productsQuery_1.getAllProducts,
    bestSellingProducts: productsQuery_1.bestSellingProducts,
    worstSellingProducts: productsQuery_1.worstSellingProducts,
    addAnProduct: productsMutation_1.addAnProduct,
    makeASell: productsMutation_1.makeASell,
    deleteAnProduct: productsMutation_1.deleteAnProduct,
    changePropertiesOfProduct: productsMutation_1.changePropertiesOfProduct,
    login: usersMutation_1.login,
    register: usersMutation_1.register,
    changeRole: usersMutation_1.changeRole,
    requestPasswordLink: usersMutation_1.requestPasswordLink,
    resetUserPassword: usersMutation_1.resetUserPassword
};
