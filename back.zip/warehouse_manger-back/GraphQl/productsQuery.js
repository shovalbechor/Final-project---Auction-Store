"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productStatus = exports.searchForProducts = exports.getAllProducts = exports.bestSellingProducts = exports.worstSellingProducts = void 0;
const data_source_1 = require("../data-source");
const product_1 = require("../entity/product");
const worstSellingProducts = async ({ limit = 5 }) => {
    const products = await data_source_1.AppDataSource.manager.find(product_1.Product);
    products.sort((a, b) => {
        return a.numberOfSales - b.numberOfSales;
    });
    return products.slice(0, limit);
};
exports.worstSellingProducts = worstSellingProducts;
const bestSellingProducts = async ({ limit = 5 }) => {
    const products = await data_source_1.AppDataSource.manager.find(product_1.Product);
    products.sort((a, b) => {
        return b.numberOfSales - a.numberOfSales;
    });
    return products.slice(0, limit);
};
exports.bestSellingProducts = bestSellingProducts;
const getAllProducts = async () => {
    return await data_source_1.AppDataSource.manager.find(product_1.Product);
};
exports.getAllProducts = getAllProducts;
const searchForProducts = async ({ name }) => {
    const nameLower = name.toLowerCase();
    const product = await data_source_1.productRepository.createQueryBuilder("product").where("LOWER(product.name)" +
        " like :name", { name: `%${nameLower}%` }).getMany();
    if (product.length === 0 || !product)
        throw new Error(`There is no product containing '${name}'`);
    return product;
};
exports.searchForProducts = searchForProducts;
const productStatus = async ({ name }) => {
    const nameLower = name.toLowerCase();
    const product = await data_source_1.productRepository.createQueryBuilder("product").where("LOWER(product.name)" +
        " like :name", { name: `%${nameLower}%` }).getOne();
    if (!product)
        return { message: `There is no product containing '${name}'` };
    const status = product.quantity > 0 ? "Available" : "Sold Out";
    return { name: product.name, status: status };
};
exports.productStatus = productStatus;
