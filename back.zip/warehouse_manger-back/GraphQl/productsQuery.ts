import {
    AppDataSource,
    productRepository, userRepository
} from "../data-source";
import {Product} from "../entity/product";
import {generateConfirmationLink} from "../utils/linksGenerator";
import {generateConfirmationBodyMail, generateWinningLink, sendEmail} from "../utils/emailClient";
import {User} from "../entity/User";

// export const worstSellingProducts = async ({limit = 5}) => {
//     const products: Array<Product> = await AppDataSource.manager.find(Product);
//     products.sort((a: Product, b: Product) => {
//         return a.numberOfSales - b.numberOfSales;
//     });
//     return products.slice(0, limit);
// };
// export const bestSellingProducts = async ({limit = 5}) => {
//     const products: Array<Product> = await AppDataSource.manager.find(Product);
//     products.sort((a: Product, b: Product) => {
//         return b.numberOfSales - a.numberOfSales;
//     });
//     return products.slice(0, limit);
// };

export const getAllProducts = async () => {
    const products: Array<Product> = await AppDataSource.manager.find(Product);
    new Promise(()=>products.map((product: Product) => {
        const expiredDate  = (new Date(product.expiredAt.getTime()+ 1000*3*60*60).getTime())- Date.now();
        if (!product.informed && expiredDate < 0){
            if (!product.lastBidId) return productRepository.update(product.id, {informed: true});
            userRepository.findOneBy({id: product.lastBidId}).then((user: User) => {
                const mailOptions = generateWinningLink(user.email, user.username, product);
                sendEmail(null, null, mailOptions, null).then((status: boolean) => {
                    if (status) productRepository.update(product.id, {informed: true});
                });
            });
        }
    }));
    return products;
};

export const searchForProducts = async ({name}) => {
    const nameLower = name.toLowerCase();
    try {
        const product = await productRepository.createQueryBuilder("product").where("LOWER(product.name)" +
            " like :name", {name: `%${nameLower}%`}).getMany();
        if (product.length === 0 || !product) throw new Error(`There is no product containing '${name}'`);
        return product;
    }catch (e) {
        console.log(e);
        throw e;
    }
};
// export const productStatus = async ({name}) => {
//     const nameLower = name.toLowerCase();
//     try {
//     const product = await productRepository.createQueryBuilder("product").where("LOWER(product.name)" +
//         " like :name", {name: `%${nameLower}%`}).getOne();
//         if (!product) return {message: `There is no product containing '${name}'`};
//         const status = product.quantity > 0 ? "Available" : "Sold Out";
//         return {name: product.name, status: status};
//     }catch (e) {
//         console.log(e);
//         return {message: `error while searching for product containing '${name}'`};
//     }
// };

