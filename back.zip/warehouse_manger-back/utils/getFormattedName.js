"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getFormattedName = void 0;
function getFormattedName(name) {
    return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
}
exports.getFormattedName = getFormattedName;
