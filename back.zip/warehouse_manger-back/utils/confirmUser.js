"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.confirmUser = void 0;
const data_source_1 = require("../data-source");
async function confirmUser(userId, res) {
    const user = await data_source_1.usersRepository.findOne({ where: { id: userId } });
    if (!user) {
        res.status(404).send("Page not found");
        return;
    }
    if (user.confirmed) {
        return res.send("User already confirmed");
    }
    user.confirmed = true;
    await data_source_1.usersRepository.update({ id: user.id }, user);
    return res.sendStatus(200);
}
exports.confirmUser = confirmUser;
