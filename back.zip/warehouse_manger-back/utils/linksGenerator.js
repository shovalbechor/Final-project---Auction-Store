"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateRequestPasswordLink = exports.generateConfirmationLink = void 0;
function generateConfirmationLink(url, userId) {
    return `${url}/user/confirm/${userId}`;
}
exports.generateConfirmationLink = generateConfirmationLink;
function generateRequestPasswordLink(url, userId) {
    return `${url}/reset/${userId}`;
}
exports.generateRequestPasswordLink = generateRequestPasswordLink;
