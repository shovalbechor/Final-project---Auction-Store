"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkIfQuantityIsValid = void 0;
function checkIfQuantityIsValid(quantity, numberOfItemsSold) {
    if (quantity - numberOfItemsSold < 0 ||
        numberOfItemsSold < 1)
        throw new Error(`invalid quantity: ${numberOfItemsSold}`);
}
exports.checkIfQuantityIsValid = checkIfQuantityIsValid;
