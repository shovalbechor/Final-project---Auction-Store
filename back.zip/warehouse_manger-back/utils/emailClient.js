"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateRequestPasswordBodyMail = exports.generateConfirmationBodyMail = exports.sendEmail = void 0;
const nodemailer = __importStar(require("nodemailer"));
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'warehousestaffinfo',
        pass: process.env.EMAIL_PASSWORD
    }
});
async function sendEmail(email, username, mailOptions, link) {
    try {
        await transporter.sendMail(mailOptions);
        return true;
    }
    catch (e) {
        return false;
    }
}
exports.sendEmail = sendEmail;
function generateConfirmationBodyMail(email, username, link) {
    const mailOptions = {
        to: email,
        subject: 'Thank you for registering to our website',
        text: `
         Hello ${username}!
         Thank you for registering to our website.
         Please click on the link below to verify your email address.
         Verify your email address: ${link}
        `
    };
    return mailOptions;
}
exports.generateConfirmationBodyMail = generateConfirmationBodyMail;
function generateRequestPasswordBodyMail(email, username, link) {
    const mailOptions = {
        to: email,
        subject: 'password reset link',
        text: `
         Hello ${username}!
         As you requested, here is the link to reset your password. 
         Please click on the link below to reset your password.
         Reset your password link: ${link}
        `
    };
    return mailOptions;
}
exports.generateRequestPasswordBodyMail = generateRequestPasswordBodyMail;
