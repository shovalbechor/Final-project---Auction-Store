import * as nodemailer from "nodemailer";
import {Product} from "../entity/product";

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'warehousestaffinfo',
        pass: process.env.EMAIL_PASSWORD
    }
});

export async function sendEmail(email: string, username: string, mailOptions: any, link: string): Promise<boolean> {
    try {
        await transporter.sendMail(mailOptions);
        return true
    } catch (e) {
        return false;
    }
}



export function generateWinningLink(email: string, username: string,item:Product): { to:string,subject: string; text: string } {
    const {name,price} = item;
    const mailOptions = {
        to: email,
        subject: 'Congratulations on your successful bid',
        text: `
         Hello ${username}!
         We are thrilled to inform you that you have emerged as the winning bidder in the auction for the ${name}.
         Congratulations on your successful bid!
         
        Item: ${name}
        Winning Bid Amount: $${price}
        Payment: You are required to make the winning bid amount of $${price} within the specified payment period.
        Payment options and instructions can be found on our website.
        `
    };
    return mailOptions;
}
export function generateConfirmationBodyMail(email: string, username: string,link:string): { to:string,subject: string; text: string } {
    const mailOptions = {
        to: email,
        subject: 'Thank you for registering to our website',
        text: `
         Hello ${username}!
         Thank you for registering to our website.
         Please click on the link below to verify your email address.
         Verify your email address: ${link}
        `
    };
        return mailOptions;
}

export function generateRequestPasswordBodyMail(email: string, username: string,link:string): { to:string,subject: string; text: string } {
    const mailOptions = {
        to: email,
        subject: 'password reset link',
        text: `
         Hello ${username}!
         As you requested, here is the link to reset your password. 
         Please click on the link below to reset your password.
         Reset your password link: ${link}
        `
    };
        return mailOptions;
}
